import { createApp } from 'vue'
import App from './App.vue'
import "./registerServiceWorker";
import './theme.css'

createApp(App).mount('#app')
